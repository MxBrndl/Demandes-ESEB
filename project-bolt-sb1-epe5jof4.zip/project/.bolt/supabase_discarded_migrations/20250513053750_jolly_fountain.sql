-- Create a new user
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at
) VALUES (
  gen_random_uuid(),
  'test@example.com',
  crypt('password123', gen_salt('bf')),
  now()
);

-- Create the corresponding profile
INSERT INTO public.profiles (
  id,
  email,
  role
) 
SELECT 
  id,
  email,
  'user'
FROM auth.users 
WHERE email = 'test@example.com';