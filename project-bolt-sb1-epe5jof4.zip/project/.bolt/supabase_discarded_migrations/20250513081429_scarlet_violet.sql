/*
  # Add delete policy for requests table

  1. Changes
    - Add policy to allow admins to delete requests
    - Maintain existing RLS policies

  2. Security
    - Enable RLS on requests table
    - Add policy for admins to delete requests
*/

-- Create delete policy for admins
CREATE POLICY "Admins can delete requests"
ON requests FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);