/*
  # Fix RLS policies for requests table

  1. Changes
    - Remove existing RLS policies for requests table
    - Add new policies that properly handle admin and user access
    - Ensure proper access control based on user roles

  2. Security
    - Enable RLS on requests table
    - Add policies for:
      - Admins can read all requests
      - Users can read their own requests
      - Users can create requests
      - Admins can update all requests
      - Users can update their own requests
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can read all requests" ON requests;
DROP POLICY IF EXISTS "Users can read their own requests" ON requests;
DROP POLICY IF EXISTS "Users can create requests" ON requests;
DROP POLICY IF EXISTS "Admins can update all requests" ON requests;
DROP POLICY IF EXISTS "Users can update their own requests" ON requests;

-- Create new policies
CREATE POLICY "Admins can read all requests"
ON requests FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Users can read their own requests"
ON requests FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can create requests"
ON requests FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can update all requests"
ON requests FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Users can update their own requests"
ON requests FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);