/*
  # Create Test Users
  
  Creates multiple test users with different roles, handling potential duplicates.
  
  1. Changes
    - Create admin and regular test users
    - Handle duplicate entries gracefully
    - Ensure proper auth setup
*/

-- First clean up any existing test users
DO $$
BEGIN
  -- Delete from auth.users which will cascade to profiles
  DELETE FROM auth.users 
  WHERE email IN (
    'admin@example.com',
    'user1@example.com',
    'user2@example.com'
  );
END $$;

-- Function to safely create a user and profile
CREATE OR REPLACE FUNCTION create_test_user(
  p_email text,
  p_full_name text,
  p_role user_role
) RETURNS void AS $$
DECLARE
  v_user_id uuid;
  v_encrypted_pass text;
BEGIN
  -- Check if user already exists
  IF EXISTS (SELECT 1 FROM auth.users WHERE email = p_email) THEN
    RAISE NOTICE 'User % already exists, skipping', p_email;
    RETURN;
  END IF;

  -- Generate UUID and encrypted password
  v_user_id := gen_random_uuid();
  v_encrypted_pass := crypt('123456789', gen_salt('bf'));
  
  -- Create auth.users entry
  INSERT INTO auth.users (
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_sent_at,
    instance_id,
    is_super_admin,
    is_sso_user
  ) VALUES (
    v_user_id,
    'authenticated',
    'authenticated',
    p_email,
    v_encrypted_pass,
    NOW(),
    '{"provider": "email", "providers": ["email"]}'::jsonb,
    jsonb_build_object('full_name', p_full_name),
    NOW(),
    NOW(),
    NOW(),
    '00000000-0000-0000-0000-000000000000',
    FALSE,
    FALSE
  );

  -- Create profile entry
  INSERT INTO public.profiles (
    id,
    email,
    full_name,
    role
  ) VALUES (
    v_user_id,
    p_email,
    p_full_name,
    p_role
  );

EXCEPTION
  WHEN unique_violation THEN
    RAISE NOTICE 'Duplicate key violation for user %, skipping', p_email;
  WHEN others THEN
    RAISE NOTICE 'Error creating user %: %', p_email, SQLERRM;
END;
$$ LANGUAGE plpgsql;

-- Create test users
DO $$
BEGIN
  -- Create admin test user
  PERFORM create_test_user('admin@example.com', 'Admin User', 'admin');
  
  -- Create regular test users
  PERFORM create_test_user('user1@example.com', 'Regular User 1', 'user');
  PERFORM create_test_user('user2@example.com', 'Regular User 2', 'user');
END $$;

-- Clean up
DROP FUNCTION IF EXISTS create_test_user;