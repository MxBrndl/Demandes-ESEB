/*
  # Delete specific user
  
  Removes the user mbrendel@vdl.lu from both auth.users and profiles tables.
*/

-- Delete from auth.users which will cascade to profiles
DELETE FROM auth.users 
WHERE email = 'mbrendel@vdl.lu';