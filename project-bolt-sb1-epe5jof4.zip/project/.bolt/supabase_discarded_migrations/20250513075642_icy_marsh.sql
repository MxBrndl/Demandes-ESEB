/*
  # Update requests table RLS policies

  1. Changes
    - Simplify admin access policy for better performance
    - Ensure proper role-based access control
    - Maintain existing user-specific access

  2. Security
    - Maintain RLS enabled
    - Update policies for better security and performance
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can read all requests" ON requests;
DROP POLICY IF EXISTS "Admins can update all requests" ON requests;

-- Create new simplified admin policies
CREATE POLICY "Admins can read all requests"
ON requests
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Admins can update all requests"
ON requests
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);