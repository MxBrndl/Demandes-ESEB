/*
  # Add device information to requests table

  1. Changes
    - Add device_info column to requests table to store serial numbers and asset tags
    - Column is JSONB type to store nested device information flexibly

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE requests
ADD COLUMN IF NOT EXISTS device_info JSONB DEFAULT NULL;