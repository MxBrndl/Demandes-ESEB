import React from 'react';
import { RequestStatus } from '../types';

interface StatusBadgeProps {
  status: RequestStatus;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const getStatusStyles = () => {
    switch (status) {
      case 'en_attente':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'en_cours':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'prepare':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'contacte':
        return 'bg-indigo-100 text-indigo-800 border-indigo-300';
      case 'termine':
        return 'bg-teal-100 text-teal-800 border-teal-300';
      case 'approuve':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'refuse':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStatusLabel = () => {
    switch (status) {
      case 'en_attente':
        return 'En attente';
      case 'en_cours':
        return 'En cours';
      case 'prepare':
        return 'Préparé';
      case 'contacte':
        return 'Contacté';
      case 'termine':
        return 'Terminé';
      case 'approuve':
        return 'Approuvé';
      case 'refuse':
        return 'Refusé';
      default:
        return 'Inconnu';
    }
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusStyles()}`}>
      {getStatusLabel()}
    </span>
  );
};

export default StatusBadge;