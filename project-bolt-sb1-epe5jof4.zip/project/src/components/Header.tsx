import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Laptop, ClipboardList, LogOut, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const Header: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAdmin, signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
      // Always navigate and show success message, even if signOut had to handle an expired session
      navigate('/login');
      toast.success('Déconnexion réussie');
    } catch (error) {
      console.error('Sign out error:', error);
      // If there's an error, still navigate to login but show an informative message
      navigate('/login');
      toast.error('Session expirée. Veuillez vous reconnecter.');
    }
  };

  if (['/login', '/register'].includes(location.pathname)) {
    return null;
  }

  return (
    <header className="bg-gray-900 text-white shadow-md">
      <div className="container mx-auto px-4 py-5">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 mb-4 md:mb-0">
            <Laptop size={28} className="text-blue-400" />
            <span className="text-xl font-bold">Demandes ESEB</span>
          </Link>
          
          <nav className="flex items-center space-x-4">
            <Link 
              to="/demande" 
              className={`px-3 py-2 rounded-md transition duration-150 ease-in-out hover:bg-gray-800 flex items-center space-x-1 ${
                location.pathname === '/demande' ? 'bg-gray-800' : ''
              }`}
            >
              <span>Nouvelle Demande</span>
            </Link>
            
            <Link 
              to="/admin" 
              className={`px-3 py-2 rounded-md transition duration-150 ease-in-out hover:bg-gray-800 flex items-center space-x-1 ${
                location.pathname === '/admin' ? 'bg-gray-800' : ''
              }`}
            >
              <ClipboardList size={18} />
              <span>Tableau de Bord</span>
            </Link>

            <Link
              to="/profile"
              className={`px-3 py-2 rounded-md transition duration-150 ease-in-out hover:bg-gray-800 flex items-center space-x-1 ${
                location.pathname === '/profile' ? 'bg-gray-800' : ''
              }`}
            >
              <User size={18} />
              <span>Profil</span>
            </Link>

            {user && (
              <button
                onClick={handleSignOut}
                className="px-3 py-2 rounded-md transition duration-150 ease-in-out hover:bg-gray-800 flex items-center space-x-1"
              >
                <LogOut size={18} />
                <span>Déconnexion</span>
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;