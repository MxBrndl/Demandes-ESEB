import { jsPDF } from 'jspdf';
import { AppRequest } from '../types';

export const generatePDF = (request: AppRequest): string => {
  const doc = new jsPDF();
  
  doc.setFontSize(16);
  doc.text('Demande d\'Appareil', 105, 20, { align: 'center' });
  
  doc.setFontSize(12);
  doc.text(`Identifiant: ${request.id}`, 20, 40);
  doc.text(`Date de création: ${new Date(request.createdAt).toLocaleDateString('fr-FR')}`, 20, 48);
  doc.text(`Statut: ${translateStatus(request.status)}`, 20, 56);
  
  doc.text('Informations du demandeur:', 20, 70);
  doc.text(`Nom: ${request.name}`, 30, 78);
  doc.text(`Prénom: ${request.firstName}`, 30, 86);
  doc.text(`Email: ${request.email}`, 30, 94);
  doc.text(`Téléphone: ${request.phone}`, 30, 102);
  doc.text(`Adresse: ${request.address}, ${request.postalCode} ${request.city}`, 30, 110);
  doc.text(`Type: ${request.requestorType === 'student' ? 'Enfant à besoin spécifique' : 'Enseignant'}`, 30, 118);

  let currentY = 132;

  if (request.requestorType === 'student' && request.parentInfo) {
    doc.text('Informations des parents:', 20, currentY);
    doc.text(`Nom: ${request.parentInfo.parentName}`, 30, currentY + 8);
    doc.text(`Prénom: ${request.parentInfo.parentFirstName}`, 30, currentY + 16);
    doc.text(`Email: ${request.parentInfo.parentEmail}`, 30, currentY + 24);
    doc.text(`Téléphone: ${request.parentInfo.parentPhone}`, 30, currentY + 32);
    doc.text(`Enseignant de référence: ${request.referenceTeacher}`, 30, currentY + 40);
    currentY += 54;
  }
  
  doc.text('Demande d\'appareil:', 20, currentY);
  doc.text(`Appareil: ${translateDeviceType(request.deviceType)}`, 30, currentY + 8);
  if (request.needsApplePencil) {
    doc.text('Apple Pencil requis', 30, currentY + 16);
  }
  currentY += 24;

  // Add device information if available
  if (request.deviceInfo) {
    doc.text('Informations sur les appareils:', 20, currentY);
    currentY += 8;

    if (request.deviceInfo.ipad) {
      doc.text('iPad:', 30, currentY);
      doc.text(`Numéro de série: ${request.deviceInfo.ipad.serialNumber}`, 40, currentY + 8);
      doc.text(`Asset Tag: ${request.deviceInfo.ipad.assetTag}`, 40, currentY + 16);
      currentY += 24;
    }

    if (request.deviceInfo.macbook) {
      doc.text('MacBook:', 30, currentY);
      doc.text(`Numéro de série: ${request.deviceInfo.macbook.serialNumber}`, 40, currentY + 8);
      doc.text(`Asset Tag: ${request.deviceInfo.macbook.assetTag}`, 40, currentY + 16);
      currentY += 24;
    }
  }
  
  doc.text('Applications requises:', 20, currentY);
  if (request.applications.length > 0) {
    request.applications.forEach((app, index) => {
      doc.text(`- ${app}`, 30, currentY + 8 + (index * 8));
    });
    currentY += 8 + (request.applications.length * 8);
  } else {
    doc.text('Aucune application spécifiée', 30, currentY + 8);
    currentY += 16;
  }
  
  if (request.additionalInfo) {
    doc.text('Informations supplémentaires:', 20, currentY + 8);
    doc.text(request.additionalInfo, 30, currentY + 16);
  }
  
  return doc.output('datauristring');
};

const translateStatus = (status: string): string => {
  switch (status) {
    case 'en_attente': return 'En attente';
    case 'en_cours': return 'En cours de traitement';
    case 'prepare': return 'Préparé';
    case 'contacte': return 'Contacté';
    case 'termine': return 'Terminé';
    case 'approuve': return 'Approuvé';
    case 'refuse': return 'Refusé';
    default: return 'Inconnu';
  }
};

const translateDeviceType = (deviceType: string): string => {
  switch (deviceType) {
    case 'ipad': return 'iPad';
    case 'macbook': return 'MacBook';
    case 'both': return 'iPad et MacBook';
    default: return 'Inconnu';
  }
};