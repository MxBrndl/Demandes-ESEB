import { supabase } from '../lib/supabase';
import { AppRequest } from '../types';

export const saveRequest = async (request: AppRequest): Promise<void> => {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) throw new Error('User not authenticated');

  const { error } = await supabase
    .from('requests')
    .insert([{
      id: request.id,
      user_id: user.id,
      name: request.name,
      first_name: request.firstName,
      email: request.email,
      address: request.address,
      postal_code: request.postalCode,
      city: request.city,
      phone: request.phone,
      requestor_type: request.requestorType,
      device_type: request.deviceType,
      needs_apple_pencil: request.needsApplePencil,
      applications: request.applications,
      additional_info: request.additionalInfo,
      parent_info: request.parentInfo,
      reference_teacher: request.referenceTeacher,
      status: request.status,
      device_info: request.deviceInfo
    }]);

  if (error) throw error;
};

export const getRequests = async (): Promise<AppRequest[]> => {
  try {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) return [];

    const { data: profileData } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const isAdmin = profileData?.role === 'admin';

    const query = supabase
      .from('requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (!isAdmin) {
      query.eq('user_id', user.id);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching requests:', error);
      return [];
    }

    return data.map(request => ({
      id: request.id,
      userId: request.user_id,
      name: request.name,
      firstName: request.first_name,
      email: request.email,
      address: request.address,
      postalCode: request.postal_code,
      city: request.city,
      phone: request.phone,
      requestorType: request.requestor_type,
      deviceType: request.device_type,
      needsApplePencil: request.needs_apple_pencil,
      applications: request.applications || [],
      additionalInfo: request.additional_info,
      parentInfo: request.parent_info,
      referenceTeacher: request.reference_teacher,
      status: request.status,
      createdAt: request.created_at,
      deviceInfo: request.device_info
    }));
  } catch (error) {
    console.error('Error in getRequests:', error);
    return [];
  }
};

export const getRequestById = async (id: string): Promise<AppRequest | undefined> => {
  try {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) return undefined;

    const { data: profileData } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const isAdmin = profileData?.role === 'admin';

    const query = supabase
      .from('requests')
      .select('*')
      .eq('id', id);

    if (!isAdmin) {
      query.eq('user_id', user.id);
    }

    const { data, error } = await query.single();

    if (error || !data) {
      console.error('Error fetching request:', error);
      return undefined;
    }

    return {
      id: data.id,
      userId: data.user_id,
      name: data.name,
      firstName: data.first_name,
      email: data.email,
      address: data.address,
      postalCode: data.postal_code,
      city: data.city,
      phone: data.phone,
      requestorType: data.requestor_type,
      deviceType: data.device_type,
      needsApplePencil: data.needs_apple_pencil,
      applications: data.applications || [],
      additionalInfo: data.additional_info,
      parentInfo: data.parent_info,
      referenceTeacher: data.reference_teacher,
      status: data.status,
      createdAt: data.created_at,
      deviceInfo: data.device_info
    };
  } catch (error) {
    console.error('Error in getRequestById:', error);
    return undefined;
  }
};

export const updateRequest = async (updatedRequest: AppRequest): Promise<void> => {
  try {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error('User not authenticated');

    const { data: profileData } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const isAdmin = profileData?.role === 'admin';

    const query = supabase
      .from('requests')
      .update({
        name: updatedRequest.name,
        first_name: updatedRequest.firstName,
        email: updatedRequest.email,
        address: updatedRequest.address,
        postal_code: updatedRequest.postalCode,
        city: updatedRequest.city,
        phone: updatedRequest.phone,
        requestor_type: updatedRequest.requestorType,
        device_type: updatedRequest.deviceType,
        needs_apple_pencil: updatedRequest.needsApplePencil,
        applications: updatedRequest.applications,
        additional_info: updatedRequest.additionalInfo,
        parent_info: updatedRequest.parentInfo,
        reference_teacher: updatedRequest.referenceTeacher,
        status: updatedRequest.status,
        device_info: updatedRequest.deviceInfo
      })
      .eq('id', updatedRequest.id);

    if (!isAdmin) {
      query.eq('user_id', user.id);
    }

    const { error } = await query;
    if (error) throw error;
  } catch (error) {
    console.error('Error in updateRequest:', error);
    throw error;
  }
};

export const deleteRequest = async (id: string): Promise<void> => {
  try {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error('User not authenticated');

    const { data: profileData } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const isAdmin = profileData?.role === 'admin';

    const query = supabase
      .from('requests')
      .delete()
      .eq('id', id);

    if (!isAdmin) {
      query.eq('user_id', user.id);
    }

    const { error } = await query;
    if (error) throw error;
  } catch (error) {
    console.error('Error in deleteRequest:', error);
    throw error;
  }
};