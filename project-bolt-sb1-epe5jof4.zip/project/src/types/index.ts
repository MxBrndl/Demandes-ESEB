export type RequestStatus = 'en_attente' | 'en_cours' | 'prepare' | 'contacte' | 'termine' | 'approuve' | 'refuse';

export type DeviceType = 'ipad' | 'macbook' | 'both';

export type RequestorType = 'student' | 'teacher';

export interface DeviceDetails {
  serialNumber: string;
  assetTag: string;
}

export interface DeviceInfo {
  ipad?: DeviceDetails;
  macbook?: DeviceDetails;
}

export interface ParentInfo {
  parentName: string;
  parentFirstName: string;
  parentEmail: string;
  parentPhone: string;
}

export interface AppRequest {
  id: string;
  name: string;
  firstName: string;
  email: string;
  address: string;
  postalCode: string;
  city: string;
  phone: string;
  requestorType: RequestorType;
  deviceType: DeviceType;
  needsApplePencil: boolean;
  applications: string[];
  additionalInfo: string;
  createdAt: string;
  status: RequestStatus;
  parentInfo?: ParentInfo;
  referenceTeacher?: string;
  deviceInfo?: DeviceInfo;
}

export interface AppRequestFormData extends Omit<AppRequest, 'id' | 'createdAt' | 'status'> {}