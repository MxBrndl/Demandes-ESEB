import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, Plus, X, FileText } from 'lucide-react';
import { AppRequestFormData, AppRequest } from '../types';
import { saveRequest } from '../utils/storage';
import { generatePDF } from '../utils/pdf';
import toast from 'react-hot-toast';

const RequestForm: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<AppRequestFormData>({
    name: '',
    firstName: '',
    email: '',
    address: '',
    postalCode: '',
    city: '',
    phone: '',
    requestorType: 'student',
    deviceType: 'ipad',
    needsApplePencil: false,
    applications: [],
    additionalInfo: '',
    parentInfo: {
      parentName: '',
      parentFirstName: '',
      parentEmail: '',
      parentPhone: '',
    },
    referenceTeacher: '',
  });
  
  const [newApp, setNewApp] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type, checked } = e.target;
    if (name.startsWith('parent')) {
      setFormData(prev => ({
        ...prev,
        parentInfo: {
          ...prev.parentInfo!,
          [name]: value
        }
      }));
    } else if (type === 'checkbox') {
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleAddApp = () => {
    if (newApp.trim()) {
      setFormData(prev => ({
        ...prev,
        applications: [...prev.applications, newApp.trim()]
      }));
      setNewApp('');
    }
  };

  const handleRemoveApp = (index: number) => {
    setFormData(prev => ({
      ...prev,
      applications: prev.applications.filter((_, i) => i !== index)
    }));
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) newErrors.name = 'Le nom est requis';
    if (!formData.firstName.trim()) newErrors.firstName = 'Le prénom est requis';
    if (!formData.email.trim()) newErrors.email = 'L\'email est requis';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Format d\'email invalide';
    if (!formData.address.trim()) newErrors.address = 'L\'adresse est requise';
    if (!formData.postalCode.trim()) newErrors.postalCode = 'Le code postal est requis';
    if (!formData.city.trim()) newErrors.city = 'La ville est requise';
    if (!formData.phone.trim()) newErrors.phone = 'Le téléphone est requis';

    if (formData.requestorType === 'student') {
      if (!formData.parentInfo?.parentName.trim()) newErrors.parentName = 'Le nom du parent est requis';
      if (!formData.parentInfo?.parentFirstName.trim()) newErrors.parentFirstName = 'Le prénom du parent est requis';
      if (!formData.parentInfo?.parentEmail.trim()) newErrors.parentEmail = 'L\'email du parent est requis';
      else if (!/\S+@\S+\.\S+/.test(formData.parentInfo.parentEmail)) newErrors.parentEmail = 'Format d\'email invalide';
      if (!formData.parentInfo?.parentPhone.trim()) newErrors.parentPhone = 'Le téléphone du parent est requis';
      if (!formData.referenceTeacher?.trim()) newErrors.referenceTeacher = 'L\'enseignant de référence est requis';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePreview = () => {
    if (!validateForm()) return;
    
    const request: AppRequest = {
      ...formData,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      status: 'en_attente'
    };
    
    const pdfUrl = generatePDF(request);
    setPdfPreviewUrl(pdfUrl);
    setIsPreviewOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    const newRequest: AppRequest = {
      ...formData,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      status: 'en_attente'
    };
    
    saveRequest(newRequest);
    toast.success('Demande soumise avec succès !');
    navigate('/admin');
  };

  const showApplePencilOption = formData.deviceType === 'ipad' || formData.deviceType === 'both';

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">Demande d'Appareil</h1>
        
        <div className="bg-white shadow-md rounded-lg p-6 mb-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-800">Type de demandeur *</h2>
              
              <div className="flex space-x-4">
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    name="requestorType"
                    value="student"
                    checked={formData.requestorType === 'student'}
                    onChange={handleChange}
                    className="form-radio text-blue-600 h-5 w-5"
                  />
                  <span className="ml-2 text-gray-700">Enfant à besoin spécifique</span>
                </label>
                
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    name="requestorType"
                    value="teacher"
                    checked={formData.requestorType === 'teacher'}
                    onChange={handleChange}
                    className="form-radio text-blue-600 h-5 w-5"
                  />
                  <span className="ml-2 text-gray-700">Enseignant</span>
                </label>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-800">Informations personnelles</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Nom *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.name ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name}</p>}
                </div>
                
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                    Prénom *
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.firstName ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.firstName && <p className="mt-1 text-sm text-red-600">{errors.firstName}</p>}
                </div>
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.email ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
              </div>
              
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                  Adresse *
                </label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.address ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {errors.address && <p className="mt-1 text-sm text-red-600">{errors.address}</p>}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700 mb-1">
                    Code Postal *
                  </label>
                  <input
                    type="text"
                    id="postalCode"
                    name="postalCode"
                    value={formData.postalCode}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.postalCode ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.postalCode && <p className="mt-1 text-sm text-red-600">{errors.postalCode}</p>}
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                    Ville *
                  </label>
                  <input
                    type="text"
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.city ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.city && <p className="mt-1 text-sm text-red-600">{errors.city}</p>}
                </div>
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Téléphone *
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.phone ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {errors.phone && <p className="mt-1 text-sm text-red-600">{errors.phone}</p>}
              </div>
            </div>

            {formData.requestorType === 'student' && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-gray-800">Informations des parents</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="parentName" className="block text-sm font-medium text-gray-700 mb-1">
                      Nom du parent *
                    </label>
                    <input
                      type="text"
                      id="parentName"
                      name="parentName"
                      value={formData.parentInfo?.parentName}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.parentName ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {errors.parentName && <p className="mt-1 text-sm text-red-600">{errors.parentName}</p>}
                  </div>
                  
                  <div>
                    <label htmlFor="parentFirstName" className="block text-sm font-medium text-gray-700 mb-1">
                      Prénom du parent *
                    </label>
                    <input
                      type="text"
                      id="parentFirstName"
                      name="parentFirstName"
                      value={formData.parentInfo?.parentFirstName}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.parentFirstName ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {errors.parentFirstName && <p className="mt-1 text-sm text-red-600">{errors.parentFirstName}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="parentEmail" className="block text-sm font-medium text-gray-700 mb-1">
                      Email du parent *
                    </label>
                    <input
                      type="email"
                      id="parentEmail"
                      name="parentEmail"
                      value={formData.parentInfo?.parentEmail}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.parentEmail ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {errors.parentEmail && <p className="mt-1 text-sm text-red-600">{errors.parentEmail}</p>}
                  </div>
                  
                  <div>
                    <label htmlFor="parentPhone" className="block text-sm font-medium text-gray-700 mb-1">
                      Téléphone du parent *
                    </label>
                    <input
                      type="tel"
                      id="parentPhone"
                      name="parentPhone"
                      value={formData.parentInfo?.parentPhone}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.parentPhone ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {errors.parentPhone && <p className="mt-1 text-sm text-red-600">{errors.parentPhone}</p>}
                  </div>
                </div>

                <div>
                  <label htmlFor="referenceTeacher" className="block text-sm font-medium text-gray-700 mb-1">
                    Enseignant de référence *
                  </label>
                  <input
                    type="text"
                    id="referenceTeacher"
                    name="referenceTeacher"
                    value={formData.referenceTeacher}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.referenceTeacher ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.referenceTeacher && <p className="mt-1 text-sm text-red-600">{errors.referenceTeacher}</p>}
                </div>
              </div>
            )}
            
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-800">Appareil(s) demandé(s)</h2>
              
              <div className="relative">
                <label htmlFor="deviceType" className="block text-sm font-medium text-gray-700 mb-1">
                  Type d'appareil *
                </label>
                <div className="relative">
                  <select
                    id="deviceType"
                    name="deviceType"
                    value={formData.deviceType}
                    onChange={handleChange}
                    className="appearance-none w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="ipad">iPad</option>
                    <option value="macbook">MacBook</option>
                    <option value="both">iPad et MacBook</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    <ChevronDown size={16} />
                  </div>
                </div>
              </div>

              {showApplePencilOption && (
                <div className="mt-4">
                  <label className="inline-flex items-center">
                    <input
                      type="checkbox"
                      name="needsApplePencil"
                      checked={formData.needsApplePencil}
                      onChange={handleChange}
                      className="form-checkbox h-5 w-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    />
                    <span className="ml-2 text-gray-700">Apple Pencil</span>
                  </label>
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-800">Applications requises</h2>
              
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newApp}
                  onChange={(e) => setNewApp(e.target.value)}
                  placeholder="Nom de l'application"
                  className="flex-grow px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddApp())}
                />
                <button
                  type="button"
                  onClick={handleAddApp}
                  className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Plus size={18} />
                </button>
              </div>
              
              {formData.applications.length > 0 && (
                <ul className="mt-3 space-y-2">
                  {formData.applications.map((app, index) => (
                    <li key={index} className="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-md">
                      <span>{app}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveApp(index)}
                        className="text-red-500 hover:text-red-700 focus:outline-none"
                      >
                        <X size={16} />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-800">Informations supplémentaires</h2>
              
              <div>
                <textarea
                  id="additionalInfo"
                  name="additionalInfo"
                  rows={4}
                  value={formData.additionalInfo}
                  onChange={handleChange}
                  placeholder="Informations complémentaires sur la demande..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                ></textarea>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row sm:justify-between sm:space-x-4 space-y-4 sm:space-y-0 pt-4">
              <button
                type="button"
                onClick={handlePreview}
                className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FileText size={18} className="mr-2" />
                Aperçu PDF
              </button>
              
              <button
                type="submit"
                className="inline-flex items-center justify-center px-6 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Soumettre la demande
              </button>
            </div>

            <p className="text-sm text-gray-500 text-center">* Champs obligatoires</p>
          </form>
        </div>
        
        {isPreviewOpen && pdfPreviewUrl && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
              <div className="p-4 border-b flex justify-between items-center">
                <h3 className="text-lg font-semibold text-gray-900">Aperçu du PDF</h3>
                <button
                  onClick={() => setIsPreviewOpen(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="flex-grow overflow-auto">
                <iframe 
                  src={pdfPreviewUrl} 
                  className="w-full h-full min-h-[70vh]"
                  title="PDF Preview"
                />
              </div>
              <div className="p-4 border-t flex justify-end">
                <button
                  onClick={() => setIsPreviewOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RequestForm;