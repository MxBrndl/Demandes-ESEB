import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LogIn, AlertCircle, Mail, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const { signIn, resetPassword } = useAuth();
  const navigate = useNavigate();

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError('L\'email est requis');
      return false;
    }
    if (!emailRegex.test(email)) {
      setEmailError('Format d\'email invalide');
      return false;
    }
    setEmailError('');
    return true;
  };

  const validatePassword = (password: string) => {
    if (!password) {
      setPasswordError('Le mot de passe est requis');
      return false;
    }
    if (password.length < 6) {
      setPasswordError('Le mot de passe doit contenir au moins 6 caractères');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (showResetPassword) {
      if (!validateEmail(email)) return;
      
      setLoading(true);
      try {
        const { success, error } = await resetPassword(email);
        if (success) {
          setResetSent(true);
          toast.success('Si un compte existe avec cet email, vous recevrez les instructions de réinitialisation');
        } else {
          toast.error(error || 'Une erreur est survenue');
        }
      } catch (error) {
        toast.error('Erreur lors de la réinitialisation du mot de passe');
      } finally {
        setLoading(false);
      }
      return;
    }

    setEmailError('');
    setPasswordError('');

    const isEmailValid = validateEmail(email);
    const isPasswordValid = validatePassword(password);

    if (!isEmailValid || !isPasswordValid) {
      return;
    }

    setLoading(true);

    try {
      await signIn(email, password);
      toast.success('Connexion réussie');
      navigate('/admin');
    } catch (error: any) {
      const errorMessage = error?.message || 'Une erreur est survenue';
      if (errorMessage.includes('invalid_credentials')) {
        toast.error('Email ou mot de passe incorrect. Vérifiez vos identifiants ou créez un compte si vous n\'en avez pas.');
        setEmailError('Email ou mot de passe incorrect');
        setPasswordError('Email ou mot de passe incorrect');
      } else {
        toast.error('Erreur de connexion. Veuillez réessayer plus tard.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleBackToLogin = () => {
    setShowResetPassword(false);
    setResetSent(false);
    setEmail('');
    setEmailError('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            {showResetPassword ? 'Réinitialiser le mot de passe' : 'Connexion'}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            {showResetPassword 
              ? resetSent
                ? 'Vérifiez votre boîte de réception'
                : 'Entrez votre email pour recevoir les instructions'
              : 'Connectez-vous à votre compte'}
          </p>
        </div>

        {resetSent ? (
          <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Mail className="h-5 w-5 text-blue-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">
                  Instructions envoyées
                </h3>
                <div className="mt-2 text-sm text-blue-700">
                  <p>Si un compte existe avec l'email {email}, vous recevrez bientôt un email avec les instructions pour réinitialiser votre mot de passe.</p>
                  <p className="mt-2">Si vous ne recevez pas l'email :</p>
                  <ul className="list-disc list-inside mt-1">
                    <li>Vérifiez votre dossier spam</li>
                    <li>Assurez-vous que l'email est correct</li>
                    <li>Contactez le support si le problème persiste</li>
                  </ul>
                </div>
                <div className="mt-4">
                  <button
                    type="button"
                    onClick={handleBackToLogin}
                    className="inline-flex items-center text-sm text-blue-600 hover:text-blue-500"
                  >
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Retour à la connexion
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
            <div className="rounded-md shadow-sm space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    validateEmail(e.target.value);
                  }}
                  className={`mt-1 appearance-none relative block w-full px-3 py-2 border ${
                    emailError ? 'border-red-300' : 'border-gray-300'
                  } placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                  placeholder="votre@email.com"
                />
                {emailError && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <AlertCircle className="h-4 w-4 mr-1" />
                    {emailError}
                  </p>
                )}
              </div>
              {!showResetPassword && (
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    Mot de passe
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      validatePassword(e.target.value);
                    }}
                    className={`mt-1 appearance-none relative block w-full px-3 py-2 border ${
                      passwordError ? 'border-red-300' : 'border-gray-300'
                    } placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                    placeholder="Votre mot de passe"
                  />
                  {passwordError && (
                    <p className="mt-1 text-sm text-red-600 flex items-center">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      {passwordError}
                    </p>
                  )}
                </div>
              )}
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {showResetPassword ? (
                  <>
                    <Mail className="h-5 w-5 mr-2" />
                    {loading ? 'Envoi...' : 'Envoyer les instructions'}
                  </>
                ) : (
                  <>
                    <LogIn className="h-5 w-5 mr-2" />
                    {loading ? 'Connexion...' : 'Se connecter'}
                  </>
                )}
              </button>
            </div>

            <div className="flex flex-col space-y-2 text-center text-sm">
              <button
                type="button"
                onClick={() => {
                  setShowResetPassword(!showResetPassword);
                  setEmail('');
                  setEmailError('');
                  setPassword('');
                  setPasswordError('');
                }}
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                {showResetPassword 
                  ? 'Retour à la connexion'
                  : 'Mot de passe oublié ?'}
              </button>
              <Link to="/register" className="font-medium text-blue-600 hover:text-blue-500">
                Pas encore de compte ? S'inscrire
              </Link>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default Login;