import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, Trash, Save, CheckCircle, XCircle, Package, Phone, CheckSquare } from 'lucide-react';
import { AppRequest, RequestStatus, DeviceInfo } from '../types';
import { getRequestById, updateRequest, deleteRequest } from '../utils/storage';
import { generatePDF } from '../utils/pdf';
import StatusBadge from '../components/StatusBadge';
import LoadingSpinner from '../components/LoadingSpinner';
import toast from 'react-hot-toast';

const RequestDetails: React.FC = () => {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const [request, setRequest] = useState<AppRequest | null>(null);
  const [status, setStatus] = useState<RequestStatus>('en_attente');
  const [isEditing, setIsEditing] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo>({});
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [showPdfPreview, setShowPdfPreview] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const loadRequest = async () => {
      try {
        const requestData = await getRequestById(id);
        if (requestData) {
          setRequest(requestData);
          setStatus(requestData.status);
          setDeviceInfo(requestData.deviceInfo || {});
        } else {
          navigate('/admin');
        }
      } catch (error) {
        console.error('Error loading request:', error);
        toast.error('Erreur lors du chargement de la demande');
      } finally {
        setLoading(false);
      }
    };

    loadRequest();
  }, [id, navigate]);

  useEffect(() => {
    if (request) {
      const url = generatePDF(request);
      setPdfUrl(url);
    }
  }, [request]);

  const handleStatusChange = (newStatus: RequestStatus) => {
    setStatus(newStatus);
    setIsEditing(true);
    setErrors({});
    
    if (newStatus === 'prepare' && !request?.deviceInfo) {
      const newDeviceInfo: DeviceInfo = {};
      if (request?.deviceType === 'ipad' || request?.deviceType === 'both') {
        newDeviceInfo.ipad = { serialNumber: '', assetTag: '' };
      }
      if (request?.deviceType === 'macbook' || request?.deviceType === 'both') {
        newDeviceInfo.macbook = { serialNumber: '', assetTag: '' };
      }
      setDeviceInfo(newDeviceInfo);
    }
  };

  const handleDeviceInfoChange = (
    device: 'ipad' | 'macbook',
    field: 'serialNumber' | 'assetTag',
    value: string
  ) => {
    setDeviceInfo(prev => ({
      ...prev,
      [device]: {
        ...prev[device],
        [field]: value
      }
    }));
    setIsEditing(true);
    
    if (errors[`${device}_${field}`]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[`${device}_${field}`];
        return newErrors;
      });
    }
  };

  const validateDeviceInfo = (): boolean => {
    if (status !== 'prepare') return true;

    const newErrors: Record<string, string> = {};
    
    if (request?.deviceType === 'ipad' || request?.deviceType === 'both') {
      if (!deviceInfo.ipad?.serialNumber?.trim()) {
        newErrors.ipad_serialNumber = 'Le numéro de série de l\'iPad est requis';
      }
      if (!deviceInfo.ipad?.assetTag?.trim()) {
        newErrors.ipad_assetTag = 'L\'Asset Tag de l\'iPad est requis';
      }
    }
    
    if (request?.deviceType === 'macbook' || request?.deviceType === 'both') {
      if (!deviceInfo.macbook?.serialNumber?.trim()) {
        newErrors.macbook_serialNumber = 'Le numéro de série du MacBook est requis';
      }
      if (!deviceInfo.macbook?.assetTag?.trim()) {
        newErrors.macbook_assetTag = 'L\'Asset Tag du MacBook est requis';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!request) return;
    
    if (!validateDeviceInfo()) {
      toast.error('Veuillez remplir tous les champs requis');
      return;
    }

    try {
      const updatedRequest = {
        ...request,
        status,
        deviceInfo: status === 'prepare' ? deviceInfo : request.deviceInfo
      };
      
      await updateRequest(updatedRequest);
      setRequest(updatedRequest);
      setIsEditing(false);
      toast.success('Demande mise à jour avec succès');
    } catch (error) {
      console.error('Error updating request:', error);
      toast.error('Erreur lors de la mise à jour de la demande');
    }
  };

  const handleDelete = async () => {
    if (!request) return;
    
    try {
      await deleteRequest(request.id);
      toast.success('Demande supprimée avec succès');
      navigate('/admin');
    } catch (error) {
      console.error('Error deleting request:', error);
      toast.error('Erreur lors de la suppression de la demande');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="large" />
      </div>
    );
  }

  if (!request) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-gray-500">Demande non trouvée</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <button
            onClick={() => navigate('/admin')}
            className="inline-flex items-center text-blue-600 hover:text-blue-800"
          >
            <ArrowLeft size={18} className="mr-1" />
            Retour au tableau de bord
          </button>
          
          <div className="flex space-x-3">
            <button
              onClick={() => setShowPdfPreview(true)}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FileText size={18} className="mr-1" />
              Voir PDF
            </button>
            
            <button
              onClick={() => setShowDeleteModal(true)}
              className="inline-flex items-center px-3 py-2 border border-red-300 shadow-sm text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <Trash size={18} className="mr-1" />
              Supprimer
            </button>
          </div>
        </div>
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b bg-gray-50">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <h1 className="text-xl font-bold text-gray-900">
                Demande #{request.id.substring(0, 8)}
              </h1>
              
              <div className="mt-2 sm:mt-0 flex items-center">
                {isEditing ? (
                  <div className="flex space-x-2">
                    <button
                      onClick={handleSave}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <Save size={16} className="mr-1" />
                      Enregistrer
                    </button>
                    <button
                      onClick={() => {
                        setStatus(request.status);
                        setDeviceInfo(request.deviceInfo || {});
                        setIsEditing(false);
                        setErrors({});
                      }}
                      className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                    >
                      <XCircle size={16} className="mr-1" />
                      Annuler
                    </button>
                  </div>
                ) : (
                  <StatusBadge status={request.status} />
                )}
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Informations personnelles
                </h2>
                
                <dl className="space-y-3">
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Nom</dt>
                    <dd className="text-sm text-gray-900 col-span-2">{request.name}</dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Prénom</dt>
                    <dd className="text-sm text-gray-900 col-span-2">{request.firstName}</dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Email</dt>
                    <dd className="text-sm text-gray-900 col-span-2">{request.email}</dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Téléphone</dt>
                    <dd className="text-sm text-gray-900 col-span-2">{request.phone}</dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Adresse</dt>
                    <dd className="text-sm text-gray-900 col-span-2">
                      {request.address}, {request.postalCode} {request.city}
                    </dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Type</dt>
                    <dd className="text-sm text-gray-900 col-span-2">
                      {request.requestorType === 'student' ? 'Élève' : 'Enseignant'}
                    </dd>
                  </div>
                </dl>
              </div>
              
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Détails de la demande
                </h2>
                
                <dl className="space-y-3">
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Date de création</dt>
                    <dd className="text-sm text-gray-900 col-span-2">
                      {formatDate(request.createdAt)}
                    </dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Appareil demandé</dt>
                    <dd className="text-sm text-gray-900 col-span-2">
                      {request.deviceType === 'ipad' ? 'iPad' : 
                       request.deviceType === 'macbook' ? 'MacBook' : 'iPad et MacBook'}
                    </dd>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <dt className="text-sm font-medium text-gray-500">Applications</dt>
                    <dd className="text-sm text-gray-900 col-span-2">
                      {request.applications.length > 0 ? (
                        <ul className="list-disc pl-5">
                          {request.applications.map((app, index) => (
                            <li key={index}>{app}</li>
                          ))}
                        </ul>
                      ) : (
                        <span className="text-gray-500 italic">Aucune application spécifiée</span>
                      )}
                    </dd>
                  </div>
                  
                  {request.additionalInfo && (
                    <div className="grid grid-cols-3 gap-4">
                      <dt className="text-sm font-medium text-gray-500">Informations supplémentaires</dt>
                      <dd className="text-sm text-gray-900 col-span-2">
                        {request.additionalInfo}
                      </dd>
                    </div>
                  )}
                </dl>
              </div>
            </div>

            {(request.deviceInfo || status === 'prepare') && (
              <div className="mt-8 pt-6 border-t">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Informations sur les appareils
                </h2>
                
                {status === 'prepare' ? (
                  <div className="space-y-6">
                    {(request.deviceType === 'ipad' || request.deviceType === 'both') && (
                      <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                        <h4 className="font-medium text-gray-900">iPad</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700">
                              Numéro de série *
                            </label>
                            <input
                              type="text"
                              value={deviceInfo.ipad?.serialNumber || ''}
                              onChange={(e) => handleDeviceInfoChange('ipad', 'serialNumber', e.target.value)}
                              className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm ${
                                errors.ipad_serialNumber ? 'border-red-300' : 'border-gray-300'
                              }`}
                              placeholder="Numéro de série de l'iPad"
                            />
                            {errors.ipad_serialNumber && (
                              <p className="mt-1 text-sm text-red-600">{errors.ipad_serialNumber}</p>
                            )}
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700">
                              Asset Tag *
                            </label>
                            <input
                              type="text"
                              value={deviceInfo.ipad?.assetTag || ''}
                              onChange={(e) => handleDeviceInfoChange('ipad', 'assetTag', e.target.value)}
                              className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm ${
                                errors.ipad_assetTag ? 'border-red-300' : 'border-gray-300'
                              }`}
                              placeholder="Asset Tag de l'iPad"
                            />
                            {errors.ipad_assetTag && (
                              <p className="mt-1 text-sm text-red-600">{errors.ipad_assetTag}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {(request.deviceType === 'macbook' || request.deviceType === 'both') && (
                      <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                        <h4 className="font-medium text-gray-900">MacBook</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700">
                              Numéro de série *
                            </label>
                            <input
                              type="text"
                              value={deviceInfo.macbook?.serialNumber || ''}
                              onChange={(e) => handleDeviceInfoChange('macbook', 'serialNumber', e.target.value)}
                              className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm ${
                                errors.macbook_serialNumber ? 'border-red-300' : 'border-gray-300'
                              }`}
                              placeholder="Numéro de série du MacBook"
                            />
                            {errors.macbook_serialNumber && (
                              <p className="mt-1 text-sm text-red-600">{errors.macbook_serialNumber}</p>
                            )}
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700">
                              Asset Tag *
                            </label>
                            <input
                              type="text"
                              value={deviceInfo.macbook?.assetTag || ''}
                              onChange={(e) => handleDeviceInfoChange('macbook', 'assetTag', e.target.value)}
                              className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm ${
                                errors.macbook_assetTag ? 'border-red-300' : 'border-gray-300'
                              }`}
                              placeholder="Asset Tag du MacBook"
                            />
                            {errors.macbook_assetTag && (
                              <p className="mt-1 text-sm text-red-600">{errors.macbook_assetTag}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <p className="text-sm text-gray-500">* Champs obligatoires</p>
                  </div>
                ) : (
                  <dl className="space-y-3">
                    {request.deviceInfo?.ipad && (
                      <div>
                        <dt className="text-sm font-medium text-gray-900">iPad</dt>
                        <dd className="mt-1 text-sm text-gray-600">
                          <div className="grid grid-cols-3 gap-4">
                            <span className="text-gray-500">Numéro de série:</span>
                            <span className="col-span-2">{request.deviceInfo.ipad.serialNumber}</span>
                          </div>
                          <div className="grid grid-cols-3 gap-4">
                            <span className="text-gray-500">Asset Tag:</span>
                            <span className="col-span-2">{request.deviceInfo.ipad.assetTag}</span>
                          </div>
                        </dd>
                      </div>
                    )}
                    
                    {request.deviceInfo?.macbook && (
                      <div className="mt-4">
                        <dt className="text-sm font-medium text-gray-900">MacBook</dt>
                        <dd className="mt-1 text-sm text-gray-600">
                          <div className="grid grid-cols-3 gap-4">
                            <span className="text-gray-500">Numéro de série:</span>
                            <span className="col-span-2">{request.deviceInfo.macbook.serialNumber}</span>
                          </div>
                          <div className="grid grid-cols-3 gap-4">
                            <span className="text-gray-500">Asset Tag:</span>
                            <span className="col-span-2">{request.deviceInfo.macbook.assetTag}</span>
                          </div>
                        </dd>
                      </div>
                    )}
                  </dl>
                )}
              </div>
            )}
            
            <div className="mt-8 pt-6 border-t">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Gestion du statut
              </h2>
              
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => handleStatusChange('en_attente')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    status === 'en_attente'
                      ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  En attente
                </button>
                
                <button
                  onClick={() => handleStatusChange('refuse')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    status === 'refuse'
                      ? 'bg-red-100 text-red-800 border border-red-300'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <XCircle size={16} className="inline-block mr-1" />
                  Refusé
                </button>
                
                <button
                  onClick={() => handleStatusChange('approuve')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    status === 'approuve'
                      ? 'bg-green-100 text-green-800 border border-green-300'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <CheckCircle size={16} className="inline-block mr-1" />
                  Approuvé
                </button>
                
                <button
                  onClick={() => handleStatusChange('prepare')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    status === 'prepare'
                      ? 'bg-purple-100 text-purple-800 border border-purple-300'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Package size={16} className="inline-block mr-1" />
                  Préparé
                </button>
                
                <button
                  onClick={() => handleStatusChange('contacte')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    status === 'contacte'
                      ? 'bg-indigo-100 text-indigo-800 border border-indigo-300'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Phone size={16} className="inline-block mr-1" />
                  Contacté
                </button>
                
                <button
                  onClick={() => handleStatusChange('termine')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    status === 'termine'
                      ? 'bg-teal-100 text-teal-800 border border-teal-300'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <CheckSquare size={16} className="inline-block mr-1" />
                  Terminé
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {showPdfPreview && pdfUrl && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
              <div className="p-4 border-b flex justify-between items-center">
                <h3 className="text-lg font-semibold text-gray-900">Aperçu du PDF</h3>
                <button
                  onClick={() => setShowPdfPreview(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <XCircle size={20} />
                </button>
              </div>
              <div className="flex-grow overflow-auto">
                <iframe 
                  src={pdfUrl} 
                  className="w-full h-full min-h-[70vh]"
                  title="PDF Preview"
                />
              </div>
              <div className="p-4 border-t flex justify-end">
                <button
                  onClick={() => setShowPdfPreview(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}
        
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Confirmer la suppression</h3>
              <p className="text-gray-600 mb-6">
                Êtes-vous sûr de vouloir supprimer cette demande ? Cette action est irréversible.
              </p>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Annuler
                </button>
                <button
                  onClick={handleDelete}
                  className="px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  Supprimer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RequestDetails;