import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, FileText, Eye } from 'lucide-react';
import { AppRequest, RequestStatus } from '../types';
import { getRequests } from '../utils/storage';
import StatusBadge from '../components/StatusBadge';
import LoadingSpinner from '../components/LoadingSpinner';
import { useAuth } from '../contexts/AuthContext';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [requests, setRequests] = useState<AppRequest[]>([]);
  const [filteredRequests, setFilteredRequests] = useState<AppRequest[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<RequestStatus | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'student' | 'teacher'>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadRequests = async () => {
      try {
        const loadedRequests = await getRequests();
        setRequests(loadedRequests);
        setFilteredRequests(loadedRequests);
      } catch (error) {
        console.error('Error loading requests:', error);
      } finally {
        setLoading(false);
      }
    };

    loadRequests();
  }, []);

  useEffect(() => {
    let result = [...requests];
    
    if (searchTerm) {
      const lowerCaseSearch = searchTerm.toLowerCase();
      result = result.filter(
        request => 
          request.name.toLowerCase().includes(lowerCaseSearch) ||
          request.firstName.toLowerCase().includes(lowerCaseSearch) ||
          request.email.toLowerCase().includes(lowerCaseSearch) ||
          request.id.toLowerCase().includes(lowerCaseSearch) ||
          request.deviceInfo?.ipad?.serialNumber?.toLowerCase().includes(lowerCaseSearch) ||
          request.deviceInfo?.ipad?.assetTag?.toLowerCase().includes(lowerCaseSearch) ||
          request.deviceInfo?.macbook?.serialNumber?.toLowerCase().includes(lowerCaseSearch) ||
          request.deviceInfo?.macbook?.assetTag?.toLowerCase().includes(lowerCaseSearch)
      );
    }
    
    if (statusFilter !== 'all') {
      result = result.filter(request => request.status === statusFilter);
    }
    
    if (typeFilter !== 'all') {
      result = result.filter(request => request.requestorType === typeFilter);
    }
    
    setFilteredRequests(result);
  }, [searchTerm, statusFilter, typeFilter, requests]);

  const handleViewRequest = (id: string) => {
    if (isAdmin) {
      navigate(`/admin/demande/${id}`);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="large" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Tableau de Bord</h1>
        <p className="text-gray-600 mt-2">
          {isAdmin 
            ? 'Gérez et suivez toutes les demandes d\'appareils'
            : 'Consultez l\'état de vos demandes d\'appareils'}
        </p>
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="p-4 border-b">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Rechercher une demande..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-full md:w-64"
              />
            </div>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="flex items-center space-x-2">
                <Filter size={18} className="text-gray-500" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as RequestStatus | 'all')}
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="all">Tous les statuts</option>
                  <option value="en_attente">En attente</option>
                  <option value="refuse">Refusé</option>
                  <option value="approuve">Approuvé</option>
                  <option value="prepare">Préparé</option>
                  <option value="contacte">Contacté</option>
                  <option value="termine">Terminé</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <FileText size={18} className="text-gray-500" />
                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value as 'all' | 'student' | 'teacher')}
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="all">Tous les types</option>
                  <option value="student">Élève</option>
                  <option value="teacher">Enseignant</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          {filteredRequests.length > 0 ? (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Demandeur
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Appareil
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Numéro de série
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Asset Tag
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  {isAdmin && (
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredRequests.map((request) => (
                  <tr
                    key={request.id}
                    className={`hover:bg-gray-50 transition-colors ${isAdmin ? 'cursor-pointer' : ''}`}
                    onClick={() => isAdmin && handleViewRequest(request.id)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-500">
                      {request.id.substring(0, 8)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {request.firstName} {request.name}
                      </div>
                      <div className="text-sm text-gray-500">{request.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {request.requestorType === 'student' ? 'Élève' : 'Enseignant'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {request.deviceType === 'ipad' ? 'iPad' : 
                       request.deviceType === 'macbook' ? 'MacBook' : 'iPad & MacBook'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {request.deviceInfo?.ipad && (
                        <div>
                          <span className="font-medium">iPad:</span> {request.deviceInfo.ipad.serialNumber}
                        </div>
                      )}
                      {request.deviceInfo?.macbook && (
                        <div className={request.deviceInfo.ipad ? 'mt-1' : ''}>
                          <span className="font-medium">MacBook:</span> {request.deviceInfo.macbook.serialNumber}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {request.deviceInfo?.ipad && (
                        <div>
                          <span className="font-medium">iPad:</span> {request.deviceInfo.ipad.assetTag}
                        </div>
                      )}
                      {request.deviceInfo?.macbook && (
                        <div className={request.deviceInfo.ipad ? 'mt-1' : ''}>
                          <span className="font-medium">MacBook:</span> {request.deviceInfo.macbook.assetTag}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(request.createdAt)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <StatusBadge status={request.status} />
                    </td>
                    {isAdmin && (
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewRequest(request.id);
                          }}
                          className="text-blue-600 hover:text-blue-900 inline-flex items-center"
                        >
                          <Eye size={16} className="mr-1" />
                          Voir
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">Aucune demande trouvée</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;