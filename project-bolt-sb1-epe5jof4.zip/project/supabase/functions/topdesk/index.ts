import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const TOPDESK_API_URL = Deno.env.get("TOPDESK_API_URL") || "https://technolink.topdesk.net";
const TOPDESK_API_KEY = Deno.env.get("TOPDESK_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info",
  "Access-Control-Max-Age": "86400",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { 
      status: 204,
      headers: corsHeaders 
    });
  }

  try {
    if (!TOPDESK_API_KEY) {
      throw new Error("TOPdesk API key not configured");
    }

    const { name, firstName, email, phone, deviceType, additionalInfo } = await req.json();

    if (!name || !firstName || !email || !deviceType) {
      throw new Error("Missing required fields");
    }

    // Create TOPdesk incident
    const incident = {
      request: `New Device Request: ${deviceType}`,
      caller: {
        dynamicName: `${firstName} ${name}`,
        email: email,
        phone: phone
      },
      briefDescription: `Device Request: ${deviceType}`,
      category: "hardware",
      subcategory: "device-request",
      impact: "person",
      urgency: "normal",
      priority: "normal",
      notes: [
        {
          noteText: additionalInfo || "No additional information provided"
        }
      ]
    };

    // Send to TOPdesk
    const response = await fetch(`${TOPDESK_API_URL}/tas/api/incidents`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${btoa(`apitoken:${TOPDESK_API_KEY}`)}`
      },
      body: JSON.stringify(incident)
    });

    const responseData = await response.json();

    if (!response.ok) {
      throw new Error(`TOPdesk API error: ${response.status} - ${JSON.stringify(responseData)}`);
    }

    return new Response(
      JSON.stringify({ success: true, incident: responseData }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      }
    );
  } catch (error) {
    console.error("Error in TOPdesk function:", error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        details: error.stack
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      }
    );
  }
});