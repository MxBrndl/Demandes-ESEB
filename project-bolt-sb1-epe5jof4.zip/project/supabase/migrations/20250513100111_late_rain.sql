/*
  # Create device tracking tables

  1. New Tables
    - `ipads`: Stores iPad details (serial number, asset tag, status)
    - `macbooks`: Stores MacBook details (serial number, asset tag, status)
    - `request_devices`: Junction table linking requests to devices

  2. Changes
    - Remove device_info JSON column from requests table
    - Add updated_at trigger function
    - Add device status enum type

  3. Security
    - Enable RLS on all new tables
    - Add admin-only policies for device management
    - Add user policies for viewing their own device assignments
*/

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create device status type
DO $$ BEGIN
  CREATE TYPE device_status AS ENUM ('available', 'assigned', 'maintenance', 'retired');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Create iPads table
CREATE TABLE ipads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_number text UNIQUE NOT NULL,
  asset_tag text UNIQUE NOT NULL,
  status device_status DEFAULT 'available',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create MacBooks table
CREATE TABLE macbooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_number text UNIQUE NOT NULL,
  asset_tag text UNIQUE NOT NULL,
  status device_status DEFAULT 'available',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create junction table for request-device relationships
CREATE TABLE request_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid REFERENCES requests(id) ON DELETE CASCADE,
  ipad_id uuid REFERENCES ipads(id) ON DELETE SET NULL,
  macbook_id uuid REFERENCES macbooks(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT request_devices_device_check CHECK (
    (ipad_id IS NOT NULL) OR (macbook_id IS NOT NULL)
  )
);

-- Remove old device_info column from requests
ALTER TABLE requests DROP COLUMN IF EXISTS device_info;

-- Enable RLS
ALTER TABLE ipads ENABLE ROW LEVEL SECURITY;
ALTER TABLE macbooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE request_devices ENABLE ROW LEVEL SECURITY;

-- Create policies for iPads
CREATE POLICY "Admins can manage iPads"
  ON ipads
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Create policies for MacBooks
CREATE POLICY "Admins can manage MacBooks"
  ON macbooks
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Create policies for request_devices
CREATE POLICY "Users can view their own request devices"
  ON request_devices
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM requests
      WHERE requests.id = request_devices.request_id
      AND requests.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage request devices"
  ON request_devices
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Add triggers for updated_at
CREATE TRIGGER update_ipads_updated_at
  BEFORE UPDATE ON ipads
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_macbooks_updated_at
  BEFORE UPDATE ON macbooks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_request_devices_updated_at
  BEFORE UPDATE ON request_devices
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();